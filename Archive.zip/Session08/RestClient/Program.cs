﻿using System;
using System.Threading.Tasks;

namespace WebAPIClient
{
    class Program
    {
        
        static void Main(string[] args)
        {
            ProcessRepositories().Wait();
        }

        private static async Task ProcessRepositories(){

        }
    }
}
