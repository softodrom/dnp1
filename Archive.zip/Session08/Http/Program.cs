﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Http
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = GetData().GetAwaiter().GetResult();
            System.Console.WriteLine(s);
        }

        static async Task<string> GetData(){
            HttpClient client = new HttpClient();
            System.Console.WriteLine("Fetching data...");
            var str = await client.GetStringAsync("http//localhost:5000/api/");
            return str;
        }
        
    }
}
