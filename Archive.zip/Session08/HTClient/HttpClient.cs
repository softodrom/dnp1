using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace HTClient
{
    public class HttpClient : System.Net.Http.HttpMessageInvoker
    {
        static async Task Main(){
            HttpClient client = new HttpClient();
            try{
                HttpResponseMessage response = await client.GetAsync("http://www.contoso.com/");
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();

                Console.WriteLine(responseBody);
            }
            catch(HttpRequestException e){
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ",e.Message);
            }

            client.Dispose(true);
        }
        
    }
}