﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Ex03
{
    class Program
    {
        static void Main(string[] args)
        {
            Reader r = new Reader("file.txt");
            var r2 = new Reader("file2.txt");

            r.Read();
            r2.Read();

            Console.WriteLine(r.Data.Equals(r2.Data));
            Console.WriteLine("Data from r => " + r.Data);
            Console.WriteLine(r.Equals(r2));
        }
    }
}
