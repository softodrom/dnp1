﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ExServer02
{
    class Program
    {
        static void Main(string[] args)
        {
            try{
            byte[] adr = {127, 0, 0, 1};
            IPAddress ipAdr = new IPAddress(adr);
            TcpListener newsock = new TcpListener( ipAdr, 5000);
            
            
            newsock.Start();
            
            Console.WriteLine("Waiting for a client...");
            TcpClient client = newsock.AcceptTcpClient();
            NetworkStream ns = client.GetStream();
            
            string welcome = "Welcome to the DNP test server";
            var data = Encoding.ASCII.GetBytes(welcome);
            ns.Write(data, 0, data.Length);
            } catch(Exception e){
                Console.WriteLine("Error...." + e.StackTrace);
            }
        }
    }
}
