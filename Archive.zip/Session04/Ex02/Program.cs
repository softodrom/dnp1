﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Ex02
{
    class Program
    {
        static void Main(string[] args)
        {
            // Serialize the object
            var p = new Person("Cristian", "Scobiola", 12);
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("MyFile.bin", FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream, p);
            stream.Close();

            // Deserialize the object
            IFormatter formatter2 = new BinaryFormatter();
            Stream stream2 = new FileStream("MyFile.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
            Person obj = (Person) formatter2.Deserialize(stream2);
            stream.Close();
            Console.WriteLine(obj.ToString());
        }
    }
}
