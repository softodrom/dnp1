using System;

namespace Ex02
{
    [Serializable]
    public class Person
    {
        public string FirstName {get; set;}
        public string LastName {get; set;}
        public int Ssn {get; set;}

        public Person(string f, string l, int i){
            FirstName = f;
            LastName = l;
            Ssn = i;
        }

        public override string ToString() => FirstName + " " + LastName + " " + Ssn;


    }
}