﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ExClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try{
            byte[] adr = {127, 0, 0, 1};
            TcpClient client = new TcpClient("127.0.0.1", 5000);

            client.Connect(new IPEndPoint(new IPAddress(adr), 5000));
            
            NetworkStream networkStream = client.GetStream();
            byte[] abyString = Encoding.ASCII.GetBytes("Hi from a client");
            networkStream.Write(abyString, 0, 14);

            client.Close();
            } catch(Exception e){
                Console.WriteLine(e.ToString());
            }
        }
    }
}
