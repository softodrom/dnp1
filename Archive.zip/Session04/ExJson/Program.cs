﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace ExJson
{
    class Program
    {
        static void Main(string[] args)
        {
            var p = new Person{ Name = "Cristinelu", LName = "Scobi"};
            var p2 = new Person { Name = "Johny" , LName = "Travolta"};
            var p3 = new Person{ Name = "Cristinelu", LName = "Scobi"};
            var p4 = new Person{ Name = "Cristinelu", LName = "Scobi"};
            var p5 = new Person{ Name = "Cristinelu", LName = "Scobi"};
            var p6 = new Person{ Name = "Cristinelu", LName = "Scobi"};

            var list = new List<Person>();
            list.Add(p);
            list.Add(p2);
            list.Add(p3);
            list.Add(p4);
            list.Add(p5);
            list.Add(p6);


            //Write to a json file serialize
            using (StreamWriter file = File.CreateText("people.json")){
            JsonSerializer serializer = new JsonSerializer();
            serializer.Serialize(file, p2);
            }


            //Read from a json file deserialize
            StreamReader file2 = File.OpenText("people.json");
            JsonSerializer serializer2 = new JsonSerializer();
            var newP = (Person)serializer2.Deserialize(file2, typeof(Person));


            //Serialize a list in json file
            using (StreamWriter file = File.CreateText("peopleList.json")){
                JsonSerializer serializer = new JsonSerializer();
                serializer2.Serialize(file, list);
            }


            //Deserialize a list from a json file
            StreamReader file3 = File.OpenText("peopleList.json");
            List<Person> list2 = (List<Person>)serializer2.Deserialize(file3, typeof(List<Person>));
            Console.WriteLine(list2[4].LName);

        

        }
    }
}
