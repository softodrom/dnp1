using Newtonsoft.Json;

namespace ExJson
{
    public class Person
    {
        public string Name{get; set;}
        public string LName{get; set;}
    }
}