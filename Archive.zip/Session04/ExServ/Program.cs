﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ExServ
{
    class Program
    {
        static void Main(string[] args)
        {

            bool done = false;

            byte[] adr = {127, 0, 0, 1};
            IPAddress ipAdr = new IPAddress(adr);
            TcpListener listen = new TcpListener(ipAdr, 5000);
            listen.Start();

            while (!done){
            Console.WriteLine("Waiting for connection...");
            TcpClient client = listen.AcceptTcpClient();

            Console.WriteLine();
            Console.WriteLine("Connection accepted.");

            NetworkStream stream = client.GetStream();
            byte[] abyString = Encoding.ASCII.GetBytes("Hi from server");
            try{
                stream.Write(abyString, 0, 14);
                stream.Close();
                client.Close();
            } catch(Exception e){
                Console.WriteLine(e.ToString());
            }
            }
            listen.Stop();

            
            }
        }
    }