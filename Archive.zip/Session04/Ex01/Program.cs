﻿using System;
using System.IO;

namespace Ex01
{
    class Program
    {
        static void Main(string[] args)
        {
            try{
                using(var sr = new StreamReader("file.txt")){
                    string line;
                    while((line = sr.ReadLine()) != null){
                        string s = sr.ReadToEnd();
                        Console.WriteLine(s);
                        Console.WriteLine($"Size of the file ==> {s.Length}");
                    }
                }
            }
            catch(Exception e){
                Console.WriteLine("The file could not be read");
                Console.WriteLine(e.Message);
            }
        }
    }
}
