﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace Ex0201
{
    class Program
    {
        static void Main(string[] args)
        {
            var p = new Person{FirstName = "Eduard", LastName = "Munteanu", Ssn = 12};
//            MemoryStream stream = new MemoryStream();
//            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof (Person));
//            ser.WriteObject(stream, p);
//            Person p2 = (Person)ser.ReadObject(stream);

            string result = JsonConvert.SerializeObject(p);
            Console.WriteLine(result);
            Console.WriteLine();

            var newPerson = JsonConvert.DeserializeObject<Person>(result);
            Console.WriteLine($"First name => {newPerson.FirstName}");
            Console.WriteLine($"Last Name => {newPerson.LastName}");
            Console.WriteLine($"Ssn => {newPerson.Ssn}");


            List<Person> list = new List<Person> {
                new Person{FirstName = "Eduard", LastName = "Munteanu", Ssn = 12},
                new Person{FirstName = "Edic", LastName = "Munteanu", Ssn = 12},
                new Person{FirstName = "Eduard", LastName = "Munteanu", Ssn = 12},
                new Person{FirstName = "Eduard", LastName = "Munteanu", Ssn = 12},
                new Person{FirstName = "Eduard", LastName = "Munteanu", Ssn = 12},
            };

            string result2 =JsonConvert.SerializeObject(list);
            Console.WriteLine();
            Console.WriteLine("List result => " + result2);
            Console.WriteLine();

            List<Person> newList = JsonConvert.DeserializeObject<List<Person>>(result2);

            foreach (var item in newList){
                Console.WriteLine($"First name => {item.FirstName} LastName => {item.LastName} Ssn {item.Ssn}");
            }

            //Serialize in a json file
            using (StreamWriter file = File.CreateText("person.json")){
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, p);
            }

            Console.WriteLine();
            Console.WriteLine();

            //Deserialize a json file
            StreamReader file2 = File.OpenText("person2.json");
            JsonSerializer serializer2 = new JsonSerializer();
            var newP = (Person)serializer2.Deserialize(file2, typeof(Person));

            Console.WriteLine("!!!!!!!!!" + newP.FirstName + " " + newP.LastName + " " + newP.Ssn);


            //Serialize a list in a json file
            using (StreamWriter file = File.CreateText("personList.json")){
                JsonSerializer serializer3 = new JsonSerializer();
                serializer3.Serialize(file, newList);
            

            StreamReader file3 = File.OpenText("personList.json");
            JsonSerializer serializer4 = new JsonSerializer();
            List<Person> list3 = (List<Person>)serializer4.Deserialize(file3, typeof(List<Person>));
            Console.WriteLine(list3[0].FirstName + " " + list[1].FirstName);

//            string json = File.ReadAllText("person.json");
//            var list4 = JsonConvert.DeserializeObject<List<Person>>(json);
//            Console.WriteLine(list4.ToString());
        }
    }
}
;