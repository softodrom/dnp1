﻿using System;
using System.Threading;

namespace ExThr
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread t0 = new Thread( new ThreadStart(RunT0));
            t0.Start();
            Thread.Sleep(10000);

            

        }

        
        public static void RunT0(){
            for(int i = 0; i < 1000; i++){
                Console.Write('x');
                Thread.Sleep(100);
        }
    }
    }
}
