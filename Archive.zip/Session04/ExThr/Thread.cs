using System;
using System.Threading;

namespace ExThr
{
    public sealed class Thread
    {
        public Thread(ThreadStart start){}

        public ThreadPriority Priority { get; set;}
        public ThreadState ThreadStart { get;}

        public bool isAlive { get;}
        public bool isBackground { get; set;}
        
        public void Start() {
            Console.WriteLine("LOL");
            Thread.Sleep(100);
        }
        public static void Sleep(int time) {}
        public void Suspend() {}
        public void Resume() {}
        public void Join() {}
        public void Abort() {}

        public static Thread CurrentThread { get;}
    }
}