﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ExClient02
{
    class Program
    {
        static void Main(string[] args)
        {
            try{
            byte[] adr = {127 ,  0,  0, 1};
            TcpClient client = new TcpClient("127.0.0.1", 5000);

            client.Connect(new IPEndPoint(new IPAddress(adr), 5000));

            NetworkStream stream = client.GetStream();
            byte[] abyString = Encoding.ASCII.GetBytes("Hi from client");
            stream.Write(abyString, 0, 14);
            } catch(Exception e){
                Console.WriteLine("Error......" + e.StackTrace);
            }

        }
    }
}
