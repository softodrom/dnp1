﻿using System;
using System.Collections.Generic;

namespace Ex01
{
    class Program
    {
        static void Main(string[] args)
        {
            var intList = new Stack<int>();
            var stringList = new Stack<string>();
            var tab = new List<int>();
            var tab2 = new List<string>();

            tab.Add(1);           
            tab.Add(2);
            tab.Add(3);
            tab.Add(4);
            tab.Add(5);
            tab.Add(6);
            tab.Add(7);
            tab.Add(8);       


            tab2.Add("1");
            tab2.Add("2");
            tab2.Add("3");
            tab2.Add("4");
            tab2.Add("5");
            tab2.Add("6");
            tab2.Add("7");
            tab2.Add("8");               

            var st = new ForStack<int>();
            var st2 = new ForStack<string>();

            st.Do(intList, tab);
            st2.Do(stringList, tab2);


        }
    }
}
