using System;
using System.Collections;
using System.Collections.Generic;

namespace Ex01
{
    public class ForStack<T>
    {

        public void Do(Stack<T> st, List<T> tab){
            DoIt(st, tab);
        }
        public static void DoIt(Stack<T> st, List<T> tab){
            for(int i = 0; i < tab.Count; i++){
                st.Push(tab[i]);
        }
        }
    }
}