namespace Ex04
{
    public class Player
    {
        public string Shout(string str) => str;

        public string Shout(int n) => $"{n} my lucky number!";

        public string Shout(Enemy e) => $"The enemy can do {e.damage} damage to me.";
    }
}