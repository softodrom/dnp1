﻿using System;

namespace Ex04
{
    class Program
    {
        static void Main(string[] args)
        {
            var e = new Enemy(20);
            var p = new Player();

            Console.WriteLine($"1st {p.Shout("Am dat focu ")}");
            Console.WriteLine($"2nd {p.Shout(10)}");
            Console.WriteLine($"3rd {p.Shout(e)}");
        }
    }
}
