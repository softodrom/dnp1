namespace Ex04
{
    public class Enemy
    {
        public int damage;

        public Enemy(int d) => damage = d;
    }
}