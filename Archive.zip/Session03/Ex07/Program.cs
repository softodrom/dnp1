﻿using System;

namespace Ex07
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab = new int[10];
            int[] tab2 = new int[10];

            tab[0] = 0;
            tab[1] = 1;
            tab[2] = 2;
            tab[3] = 3;
            tab[4] = 4;
            tab[5] = 5;
            tab[6] = 6;
            tab[7] = 7;
            tab[8] = 8;
            tab[9] = 9;

            Calculator c = new Calculator();
            Console.WriteLine(c.DoIt(tab));
            Console.WriteLine(c.DoIt(tab2));
            Console.WriteLine(c.DoIt(1,2,3,4));
    }
}
}
