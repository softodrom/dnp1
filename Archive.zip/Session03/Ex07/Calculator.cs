namespace Ex07
{
    public class Calculator
    {
        public int DoIt(int[] tab){
            int s = 0;
            for(int i = 0; i < tab.Length; i++){
                s = s + tab[i];
            }
            return s;
        }

        public int DoIt(int i1, int i2, int i3, int i4) => i1+ i2+ i3+ i4;
    }
}