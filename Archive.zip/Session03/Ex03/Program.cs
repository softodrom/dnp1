﻿using System;
using System.Collections.Generic;

namespace Ex03
{
    class Program
    {
        static void Main(string[] args)
        {
            var l1 = new List<int>();
            var l2 = new List<string>();

            l1.Add(1);
            l1.Add(2);
            l1.Add(3);
            l1.Add(4);
            l1.Add(5);
            l1.Add(6);
            l1.Add(7);

            l2.Add("lol");
            l2.Add("oho");
            l2.Add("dai");
            l2.Add("go");
            l2.Add("nu");
            l2.Add("yes");
            l2.Add("lol");

            Console.WriteLine("Din int lista =====> " + l1.randomItem());
            Console.WriteLine("Din string lista =====> " + l2.randomItem());

        }
    }
}


    public static class Extension{
        public static T randomItem<T>(this List<T> lista){
            Random random = new Random();
            int num = random.Next(0, lista.Count - 1);
            return lista[num];
        }
    }


