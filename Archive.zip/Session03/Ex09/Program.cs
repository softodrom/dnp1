﻿using System;
using System.Collections.Generic;

namespace Ex09
{
    class Program
    {
        static void Main(string[] args)
        {
            var c1 = new Car("Red", 2.0, "50%");
            var c2 = new Car("Blue", 1.6, "75%");
            var c3 = new Car("Black", 3.1, "20%");
            var c4 = new Car("Black", 2.5, "15");
            var list = new List<Car>();
            
            list.Add(c1);
            list.Add(c2);
            list.Add(c3);
            list.Add(c4);
            
            Predicate<Car> check = colorCheck;
            Console.WriteLine(check(c1));
            Console.WriteLine(check(c2));
            Console.WriteLine(check(c3));

            Console.WriteLine();
            Console.WriteLine("=======================");
            Car c5 = list.Find(f => f.getColour().Equals("Black"));
            Console.WriteLine(c5.ToString());
            
            var list2 = list.FindAll(x => x.EngineSize > 1.7);

            Console.WriteLine();
            Console.WriteLine("------------------------");

            for(int i = 0; i < list2.Count; i++){
                Console.WriteLine($"Car no {i + 1} to string: {list2[i]}");
            }
            Console.WriteLine();
            Console.WriteLine("===================");
            var list3 = list.FindAll(y => y.EngineSize < 2.8 && y.getColour().Equals("Black"));
            for(int i = 0; i < list3.Count; i++){
                Console.WriteLine($"Car no {i + 1} to string: {list3[i]}");
            }
        }

        public static bool colorCheck(Car c) => c.getColour().Equals("Black");
    }
}
