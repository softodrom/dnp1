namespace Ex09
{
    public class Car
    {
        private string Color;
        public double EngineSize;
        private string FuelEconomy;

        public Car(string c, double e, string fe){
            Color = c;
            EngineSize = e;
            FuelEconomy = fe;
        }

        public string getColour() => Color;

        public override string ToString() => $"Car color: {Color}|| Car enigne size: {EngineSize} ||Car fuel economy {FuelEconomy}";

        
    }
}