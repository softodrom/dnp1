namespace Ex02
{
    public interface IExplodable<T>
    {
        void Explode(T radius);
         
    }
}