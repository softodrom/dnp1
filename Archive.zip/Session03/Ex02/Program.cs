﻿using System;

namespace Ex02
{
    class Program
    {
        static void Main(string[] args)
        {
            var b1 = new Bomb<int>();
            var b2 = new Bomb<double>();

            Console.WriteLine("Double explode");
            b2.Explode(2);
            Console.WriteLine("Int explode");
            b1.Explode(2);
        }
    }
}
