using System;

namespace Ex02

{
    public class Bomb<T> : IExplodable<T>
    {
        public void Explode(T radius)
        {
            if(radius is double){
                Console.WriteLine("Boom!" + " size: " + radius);
            }
        }
    }
}