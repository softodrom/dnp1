﻿using System;

namespace Ex08
{
    public delegate void Notifier(string str);
    class Program
    {
        static void Main(string[] args)
        {
            var del = new Notifier(Hello);
            var d1 = new Notifier(SayHello);
            var d2 = new Notifier(SayGoodbye);
            del("Hello");
            d1("Ion");
            d2("Ion");
            var d3 = new Notifier(SayHello);
            d3 += SayGoodbye;
            d3("Jenea");
        }
        public static void Hello(string strMessage) => Console.WriteLine(strMessage);
        public static void SayHello(string s) => Console.WriteLine($"Hello {s}");
        public static void SayGoodbye(string s) => Console.WriteLine($"Goodbye {s}");
        
    }

}
