﻿using System;

namespace Ex06
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 42;
            string message = "";
            
            if (score > 1337){
                message = "This is a new highscore!";
                }
                else{
                    message = "You need more points to beat the highscore!";
                    }

            Console.WriteLine(message);
            score = 1338;

            message = (score > 1337) ? "This is a new highscore!" : "You need more points to beat the highscore!" ; 

            Console.WriteLine(message);
        }
    }
}
