using System;

namespace Ex05
{
    public class Time
    {
        public int h;
        public int m;

        public Time(int h, int m){
            this.h = h;
            this.m = m;
        }

        public void Display(){
            Console.WriteLine("Hour >> " + h);
            Console.WriteLine("Minutes >> " + m);
        }

        public static Time operator +(Time t1, Time t2){
            Time t = new Time(t1.h + t2.h, t1.m + t2.m);
            return t;
        }
    }
}