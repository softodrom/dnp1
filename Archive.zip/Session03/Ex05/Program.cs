﻿using System;

namespace Ex05
{
    class Program
    {
        static void Main(string[] args)
        {
            var t1 = new Time(2,3);
            var t2 = new Time(4,5);
            

            Time t3 = t1 + t2;

            t1.Display();
            t2.Display();
            t3.Display();

        }
    }
}
