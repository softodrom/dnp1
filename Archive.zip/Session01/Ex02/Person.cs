﻿using System;

namespace Ex02
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 0; i <= 100; i++){
                double f = i % 2;
                if( f == 0){
                    System.Console.WriteLine(i);
                }
            }
        }
    }
}
