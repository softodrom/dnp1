﻿using System;

namespace Ex04
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = Calculator.Add(1,2);
            Console.WriteLine(result);
            int[] tab = new int[3] {1,2,3};
            Console.WriteLine(Calculator.Add(tab));
            Console.WriteLine(Calculator.Div(50, 2));
            Console.WriteLine(Calculator.Multi(50, 10));
            Console.WriteLine(Calculator.Sub(47, 7));
        }
    }
}
