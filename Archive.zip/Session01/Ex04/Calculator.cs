namespace Ex04
{
    public class Calculator
    {
        public static int Add(int a, int b){
            return a + b;
        }

        public static int Add(int[] numbers){
            int sum = 0;
            for(int i = 0; i < numbers.Length; i++){
                sum = sum + numbers[i];
            }
            return sum;
        }

        public static int Sub(int a, int b){
            return a - b;
        }

        public static int Div(int a, int b){
            if(a != 0){
                return a / b;
            }
            return 0;
        }

        public static int Multi(int a, int b){
            return a * b;
        }

    }
}