﻿using System;

namespace Ex06
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name ==> ");
            string name = Console.ReadLine();
            char[] tab = new char[name.Length];
            string reverseName = "";

            for(int i = 0; i < name.Length; i++){
                tab[i] = name[name.Length - i - 1];
            }

            for (int i = 0; i < tab.Length; i++){
                reverseName = reverseName + tab[i].ToString();
            }
            
            Console.WriteLine("Reverse name ==> " + reverseName);
        }
    }
}
