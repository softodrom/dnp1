﻿using System;

namespace Ex01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Cristian Guba");
            var person = new Person();
            person.Name = "CCR";
            person.Introduce();
            
            
        }
    }
}
