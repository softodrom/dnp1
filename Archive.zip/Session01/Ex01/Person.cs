public class Person{
    public string Name;

    public void Introduce(){
        System.Console.WriteLine("Hi, my name is " + Name);
    }
}