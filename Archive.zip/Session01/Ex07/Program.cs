﻿using System;

namespace Ex07
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "loo...l";
            string[] s2 = s.Split("...", 2);
            Console.WriteLine(s2.ToString());
        }
    }
}
