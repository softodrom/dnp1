namespace Ex07
{
    public class StringUtility
    {
        public static string SummarizeText(string s){
            if(s.Length > 20){
                s.Join("...", 20);
                s.Split("...",20, StringSplitOptions.);
            }

            return null;
        }
    }
}