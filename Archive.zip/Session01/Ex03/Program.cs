﻿using System;

namespace Ex03
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = new Random().Next(0,10);
            Console.WriteLine(number);
            switch(number){
                case 0:
                    Console.WriteLine("This is the first number");
                    break;

                case 10:
                    Console.WriteLine("This is the last number");
                    break;

                default:
                    Console.WriteLine(number);
                    break;
            }
        }
    }
}
