using System;

namespace Ex01.Data.Entities
{
    public class OrderItem
    {
        public int Id { get; set; }
        public Cat cat { get; set; }
        public int quantity { get; set; }  
        public Order order { get; set; }

    }
}