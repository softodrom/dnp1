using System;
using System.ComponentModel.DataAnnotations;

namespace Ex01.Data.Entities
{
    public class Cat
    {
        [Required]
        public int id{get; set;}
        [StringLength(20, MinimumLength = 2)]
        [Required]
        public string Name{get; set;}
        [RegularExpression(@"^[A-Z]+[a-zA-Z""'\s-]*$")]
        public string Color{get; set;}
        [Range(1, 100)]
        [DataType(DataType.Currency)]
        [Required]
        public decimal Price{get; set;}
        public DateTime Birthday{get; set;}
        public string FavoriteDash{get; set;}
    }
}