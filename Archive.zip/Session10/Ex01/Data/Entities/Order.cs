using System;
using System.Collections;

namespace Ex01.Data.Entities
{
    public class Order
    {
        public int id{get; set;}
        public DateTime OrderDate{get; set;}
        public string orderNumber{get; set;}
        public ICollection Items{get; set;}
    }
}