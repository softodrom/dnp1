using System.Linq;
using Ex01.Data.Entities;

namespace Ex01
{
    public class DbInitializer
    {
        public static void Initialize(CatContext context){
            context.Database.EnsureCreated();

            if(context.Cats.Any()){
                return;
            }

            var cats = new Cat[]{
                new Cat { id = 234, Name = "Jorik", Price = 23},
                new Cat { id = 345, Name = "Capusa" , Price = 22}
            };

            foreach(Cat c in cats){
                context.Add(c);
            }
            context.SaveChanges();
        }
    }
}