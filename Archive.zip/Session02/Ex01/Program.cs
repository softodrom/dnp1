﻿using System;

namespace Session02
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student();
            DNPStudent student2 = new DNPStudent();     

            student1.SayHi();
            student2.SayHi();

        }
    }
}
