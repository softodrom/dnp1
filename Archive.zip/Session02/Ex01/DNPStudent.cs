using System;

namespace Session02
{
    public class DNPStudent : Student
    {
        public override void SayHi(){
            base.SayHi();
            Console.WriteLine("Hi I am a DNP student!");
            }
    }
}