using System;

namespace Session02
{
    public class Student
    {
        public virtual void SayHi(){
            Console.WriteLine("Hi i am a student");
        }
    }
}