using System.Collections.Generic;

namespace Ex05
{
    public class TheList : IComparable
    {
        private List<Animal> ani = new List<Animal>();

        public void add(Animal animal){
            ani.Add(animal);
        }

        public Animal getAnimal(int i) => ani[i];

        public int Marimea() => ani.Count;

        public void Sort(){
            
        }
    }
}