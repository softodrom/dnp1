namespace Ex05
{
    public interface IComparable 
    {
        void Sort();
    }
}