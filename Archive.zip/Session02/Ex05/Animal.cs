using System.Collections.Generic;


namespace Ex05 
{
    public class Animal
    {
        private string animal;
        private double value;
        private int runSpeed;

        public Animal(string animal, double value, int runSpeed){
            this.animal = animal;
            this.value = value;
            this.runSpeed = runSpeed;
        }
        public double getValue(){
            return value;
        }

        public override string ToString() => "Animal: " + animal + " Weight " + value + " Run Speed: " + runSpeed;
    }
}