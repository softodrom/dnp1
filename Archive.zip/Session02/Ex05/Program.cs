﻿using System;
using System.Collections.Generic;

namespace Ex05
{
    class Program
    { 
        static void Main(string[] args)
        {
            List<Animal> ani = new List<Animal>();
            TheList lista = new TheList();
            
            Animal a1 = new Animal("Tiger", 200, 15);
            Animal a2 = new Animal("Cow", 569, 20);
            Animal a3 = new Animal("Pig", 460, 30);
            Animal a4 = new Animal("Cat", 120, 70);
            Animal a5 = new Animal("Dog", 700, 60);
            Animal a6 = new Animal("Lion", 1900, 130);
            Animal a7 = new Animal("Pantera", 300, 190);
            Animal a8 = new Animal("Bear", 14000, 89);
            Animal a9 = new Animal("Dear", 3400, 131);
            Animal a10 = new Animal("Monkey", 6700, 56);

            lista.add(a1);
            lista.add(a2);
            lista.add(a3);
            lista.add(a4);
            lista.add(a5);
            lista.add(a6);
            lista.add(a7);
            lista.add(a8);
            lista.add(a9);
            lista.add(a10);
            Console.WriteLine(lista.Marimea());


            for(int i = 0; i < lista.Marimea(); i++){
                Console.WriteLine(lista.getAnimal(i).ToString());
            }
        }
    }
}
