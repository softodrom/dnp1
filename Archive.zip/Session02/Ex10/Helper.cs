namespace Ex10
{
    static class Helper
    {
        public static int adding(int i, int j) => i + j;
    }
}