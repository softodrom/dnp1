﻿using System;

namespace Ex10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Helper.adding(6,7));
        }
    }
}
