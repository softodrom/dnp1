﻿using System;
using System.Collections.Generic;

namespace Ex08
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Person> nickNames = new Dictionary<string, Person>();
            Person p1 = new Person("Ion", 20, 130);
            Person p2 = new Person("Johny" , 24, 87);
            Person p3 = new Person("Vanea" , 29, 198);
            
            nickNames.Add("Ionut", p1);
            nickNames.Add("Jonicic" , p2);
            nickNames.Add("Vaniusa" , p3);

            Console.WriteLine(nickNames["Ionut"].toString());

            foreach (var key in nickNames.Keys){
                Console.WriteLine(nickNames[key].toString()+$" Nickname: {key}");
            }


        }
    }
}
