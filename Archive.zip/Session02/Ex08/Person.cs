namespace Ex08
{
    public class Person
    {
        public string name{ get; set; }
        public int age{ get; set; }
        public int power{get; set; }
        
        public Person(string name, int age, int power){
            this.name = name;
            this.age = age;
            this.power = power;
        }

        public string toString() => name + " " + age + " " + power;
    }
}