namespace Ex04
{
    public interface IComparable
    {
        void Sort();
    }
}