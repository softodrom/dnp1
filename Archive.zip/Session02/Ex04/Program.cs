﻿using System;
using System.Collections.Generic;

namespace Ex04
{
    class Program
    { 
        static void Main(string[] args)
        {
            List<Animal> ani = new List<Animal>();
            Console.WriteLine("Hello World!");
            Animal a1 = new Animal("Tiger", 200, 15);
            Animal a2 = new Animal("Cow", 569, 20);
            Animal a3 = new Animal("Pig", 460, 30);
            Animal a4 = new Animal("Cat", 120, 70);
            Animal a5 = new Animal("Dog", 700, 60);
            Animal a6 = new Animal("Lion", 1900, 130);
            Animal a7 = new Animal("Pantera", 300, 190);
            Animal a8 = new Animal("Bear", 14000, 89);
            Animal a9 = new Animal("Dear", 3400, 131);
            Animal a10 = new Animal("Monkey", 6700, 56);

            for(int i = 0; i < ani.Count; i++){
                Console.WriteLine(ani[i]);
            }
        }
    }
}
