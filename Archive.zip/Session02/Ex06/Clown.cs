namespace Ex06
{
    public class Clown
    {
        
    }
}