namespace Ex06
{
    public class Circus
    {
        Clown c1 = new Clown();
    }
}