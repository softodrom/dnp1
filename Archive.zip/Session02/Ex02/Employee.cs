using System;

namespace Ex02
{
    public abstract class Employee
    {
        public string name;

        public Employee(String st) => name = st;

        public abstract double GetMonthlySalary();
        
    }
}