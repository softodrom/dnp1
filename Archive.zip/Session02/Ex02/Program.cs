﻿using System;

namespace Ex02
{
    class Program
    {
        static void Main(string[] args)
        {
            Company comp = new Company();

            FullTimeEmployee emp1 = new FullTimeEmployee(2000, "Oleg Eni");
            PartTimeEmployee emp2 = new PartTimeEmployee(180, 42, "Dan Plamadeala");
            FullTimeEmployee emp3 = new FullTimeEmployee(2450, "Drotki");
            PartTimeEmployee emp4 = new PartTimeEmployee(120, 42, "Scobiola Cristian");
            PartTimeStudent emp5 = new PartTimeStudent(155, 42, "Andrei Balanuta");

            comp.EmployNewEmployee(emp1);
            comp.EmployNewEmployee(emp2);
            comp.EmployNewEmployee(emp3);
            comp.EmployNewEmployee(emp4);
            comp.EmployNewEmployee(emp5);

            emp5.Register(2018);
            Console.WriteLine("NEW STUDENT" + emp5.GetMonthlySalary());
            Console.WriteLine("STUDENT " + emp5.ToString());

            Console.WriteLine("1st " + emp1.GetMonthlySalary());
            Console.WriteLine("2nd " + emp2.GetMonthlySalary());
            Console.WriteLine("3rd " + emp3.GetMonthlySalary());
            Console.WriteLine("4th " + emp4.GetMonthlySalary());
            Console.WriteLine();



            Console.WriteLine("Total: " + comp.getMonthlySalaryTotal());

        }
    }
}
