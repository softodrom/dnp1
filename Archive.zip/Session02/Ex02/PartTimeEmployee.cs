using System;

namespace Ex02
{
    public class PartTimeEmployee : Employee
    {
        private double hourlyWage;
        private int hoursPerMonth;

        public PartTimeEmployee(double hourlyWage, int hoursPerMonth, string name):base(name){
            this.hourlyWage = hourlyWage;
            this.hoursPerMonth = hoursPerMonth;
            base.name = name;
        }

        public override double GetMonthlySalary(){
            return hourlyWage * hoursPerMonth;
        }
    }
}