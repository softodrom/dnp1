namespace Ex02
{
    public class PartTimeStudent : PartTimeEmployee, IStudent
    {
        private int year;
        public PartTimeStudent(double hourlyWage, int hoursPerMonth, string name) : base(hourlyWage, hoursPerMonth, name){}

        public void Register(int year)
        {
            this.year = year;
        }
    }
}