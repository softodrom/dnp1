using System;

namespace Ex02
{
    public class Company
    {
        private Employee[]  employs = new Employee[10];
        private int i;
        public double getMonthlySalaryTotal(){
            double total = 0;
            for(int j = 0 ; j < i; j++){
                total = total + employs[j].GetMonthlySalary();
            }
            return total;
        }

        public void EmployNewEmployee(Employee NewEmployee){
            employs[i] = NewEmployee;
            i++;
        }
        
    }
}