namespace Ex02
{
    public interface IStudent
    {
         void Register(int year);
    }
}