using System;

namespace Ex09
{
    public class Gun
    {
        private static int gunCount;
        private static int bulletCount;
        private int shotsFired;

        public Gun() => gunCount++;

        public void Shoot(){
            bulletCount++;
            shotsFired++;
            Console.WriteLine("BANG!");
        }

        public override String ToString() => "Gun count: " + gunCount + " Bullet count: " + bulletCount + " Shots fired: " + shotsFired;

    }
}