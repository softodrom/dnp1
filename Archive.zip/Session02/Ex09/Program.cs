﻿using System;

namespace Ex09
{
    class Program
    {
        static void Main(string[] args)
        {
            Gun g1 = new Gun();
            Gun g2 = new Gun();
            Gun g3 = new Gun();

            g1.Shoot();
            g2.Shoot();
            g3.Shoot();
            g1.Shoot();
            g2.Shoot();
            g2.Shoot();
            g2.Shoot();
            g2.Shoot();
            g2.Shoot();
            g1.Shoot();

            Console.WriteLine("GUN 1: " + g1.ToString());
            Console.WriteLine("GUN 2: " + g2.ToString());
            Console.WriteLine("GUN 3: " + g3.ToString());
        }
    }
}
