﻿using System;

namespace Ex07
{
    class Program
    {
        static void Main(string[] args)
        {
            Schedule tab = new Schedule();
            tab.add(DateTime.Now);
            Console.WriteLine(tab.get(0).ToString());
            tab.add(DateTime.Now.ToString());
            Console.WriteLine(tab.getString(0));

        }
    }
}
