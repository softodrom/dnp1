namespace Ex07
{
    public class HashTable<T>
    {
        private T[] arr = new T[100];

        public T this[int i]{
            get { return arr[i];}
            set { arr[i] = value;}
        }




        
    }
}