namespace Ex07
{
    public class Schedule
    {
        private HashTable<object> objectCollection = new HashTable<object>();
        private HashTable<string> stringCollection = new HashTable<string>();
        private int i;
        private int j;

        public void add(object element){
            objectCollection[i] = element;
            i++;
        }

        public void add(string element){
            stringCollection[j] = element;
            j++;
        }

        public object get(int i) => objectCollection[i];
        public string getString(int j) => stringCollection[j];
    }
}